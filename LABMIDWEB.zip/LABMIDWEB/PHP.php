<?php
session_start();

/* initialize session */

if(!isset($_SESSION["students"])){
$_SESSION["students"] = [];
}

/* add student */

if(isset($_POST["add"])){

$name = $_POST["name"];
$marks = $_POST["marks"];

$_SESSION["students"][] = [
"name"=>$name,
"marks"=>$marks
];

}

/* delete */

if(isset($_GET["delete"])){

$id = $_GET["delete"];

unset($_SESSION["students"][$id]);

}

/* clear */

if(isset($_GET["clear"])){

unset($_SESSION["students"]);

}

?>

<!DOCTYPE html>
<html>

<head>
<title>Student Manager</title>
</head>

<body>

<h2>Add Student</h2>

<form method="POST">

Name:
<input type="text" name="name">

Marks:
<input type="number" name="marks">

<button type="submit" name="add">Add</button>

</form>

<hr>

<h2>Student List</h2>

<table border="1">

<tr>
<th>Name</th>
<th>Marks</th>
<th>Action</th>
</tr>

<?php

if(isset($_SESSION["students"])){

foreach($_SESSION["students"] as $index=>$student){

echo "<tr>";

echo "<td>".$student["name"]."</td>";

echo "<td>".$student["marks"]."</td>";

echo "<td><a href='?delete=$index'>Delete</a></td>";

echo "</tr>";

}

}

?>

</table>

<br>

<a href="?clear=1">Clear All</a>

</body>

</html>